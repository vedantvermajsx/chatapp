import mongoose from 'mongoose';

const roomMessageReadSchema = new mongoose.Schema(
  {
    userId:            { type: String, required: true },
    roomId:            { type: String, required: true },
    lastReadMessageId: { type: String, default: null },
    lastReadAt:        { type: Date,   default: null },
    // Position-based read marker: number of (non-system) room messages this
    // user has read. Unread is derived as totalMessages - readCount instead
    // of maintaining a separate per-member counter that has to be touched
    // for every member on every send.
    readCount:         { type: Number, default: 0 }
  },
  { timestamps: true, versionKey: false }
);

roomMessageReadSchema.index({ userId: 1, roomId: 1 }, { unique: true });
roomMessageReadSchema.index({ roomId: 1 });

export default mongoose.models.RoomMessageRead ||
  mongoose.model('RoomMessageRead', roomMessageReadSchema);
