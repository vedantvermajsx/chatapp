import UnreadCacheService from '../../services/UnreadCacheService.js';
import Message from '../../models/message.model.js';
import Room from '../../models/room.model.js';
import UserRoom from '../../models/userRoom.model.js';
import ConversationRead from '../../models/conversationRead.model.js';

async function getUserRoomIds(userId) {
  let userRoom = await UserRoom.findOne({ userId }).lean();
  let roomIds = userRoom?.roomIds?.map(String) ?? null;

  if (!roomIds) {
    const rooms = await Room.find({ groupMembers: userId }, '_id').lean();
    roomIds = rooms.map(r => String(r._id));
    if (roomIds.length > 0) {
      await UserRoom.findOneAndUpdate(
        { userId },
        { $set: { roomIds } },
        { upsert: true }
      );
    }
  }

  return roomIds ?? [];
}

async function computePrivateFromDB(userId) {
  const result = {};

  const readRecords = await ConversationRead.find({ receiverId: userId }).lean();

  const privatePipeline = [
    {
      $match: {
        receiverId: userId,
        roomId: null,
        isSystemMessage: { $ne: true }
      }
    },
    {
      $addFields: {
        lastSeenAt: {
          $let: {
            vars: {
              record: {
                $arrayElemAt: [
                  {
                    $filter: {
                      input: readRecords,
                      as: 'r',
                      cond: { $eq: ['$$r.senderId', '$senderId'] }
                    }
                  },
                  0
                ]
              }
            },
            in: '$$record.lastSeenAt'
          }
        }
      }
    },
    {
      $match: {
        $expr: {
          $or: [
            { $eq: [{ $ifNull: ['$lastSeenAt', null] }, null] },
            { $gt: ['$timestamp', '$lastSeenAt'] }
          ]
        }
      }
    },
    { $group: { _id: '$senderId', count: { $sum: 1 } } }
  ];

  const privateCounts = await Message.aggregate(privatePipeline);
  privateCounts.forEach(({ _id, count }) => {
    if (count > 0) result[`private_${_id}`] = count;
  });

  return result;
}

export const getUnread = async (req, res) => {
  const { userId } = req.params;
  try {
    let privateCached = UnreadCacheService.getAll(userId);
    if (privateCached === null) {
      privateCached = await computePrivateFromDB(userId);
      UnreadCacheService.seed(userId, privateCached);
    }

    const roomIds = await getUserRoomIds(userId);
    const counts = await UnreadCacheService.getAllWithRooms(userId, roomIds);

    res.json({ cold: false, counts });
  } catch (err) {
    console.error('[unread.controller] getUnread error:', err);
    res.status(500).json({ error: err.message });
  }
};

export const incrementUnread = (req, res) => {
  const { userId } = req.params;
  const { chatKey } = req.body;
  if (!chatKey) return res.status(400).json({ message: 'chatKey required' });
  UnreadCacheService.increment(userId, chatKey);
  res.json({ ok: true });
};

export const seedRoomOnJoin = async (req, res) => {
  const { userId, roomId } = req.params;
  try {
    await UnreadCacheService.seedRoomOnJoin(userId, roomId);
    res.json({ ok: true });
  } catch (err) {
    console.error('[unread.controller] seedRoomOnJoin error:', err);
    res.status(500).json({ error: err.message });
  }
};

export const resetUnread = async (req, res) => {
  const { userId } = req.params;
  const { chatKey } = req.body;
  if (!chatKey) return res.status(400).json({ message: 'chatKey required' });
  const count = await UnreadCacheService.reset(userId, chatKey);
  res.json({ ok: true, count });
};

export const decrementUnread = async (req, res) => {
  const { userId } = req.params;
  const { chatKey, by } = req.body;
  if (!chatKey) return res.status(400).json({ message: 'chatKey required' });
  const count = await UnreadCacheService.decrement(userId, chatKey, Number(by) || 1);
  res.json({ ok: true, count });
};

export const seedUnread = (req, res) => {
  const { userId } = req.params;
  const { counts } = req.body;
  if (!counts) return res.status(400).json({ message: 'counts required' });
  UnreadCacheService.seed(userId, counts);
  res.json({ ok: true });
};

export const invalidateUnread = (req, res) => {
  const { userId } = req.params;
  UnreadCacheService.invalidate(userId);
  res.json({ ok: true });
};
