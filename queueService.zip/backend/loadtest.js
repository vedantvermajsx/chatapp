const BASE_URL = 'http://127.0.0.1:4000';
const ROOM_IDS = [
  '6a3e01cbfffb475b62828335',
];

const NUM_BOTS         = 100;
const MESSAGES_PER_BOT = 20;
const BOT_BATCH        = 100;

const stats = {
  calls: {},
  latencies: [],
  startTime: 0,
  endTime: 0,
};

function record(name, ms, ok) {
  if (!stats.calls[name]) stats.calls[name] = { ok: 0, fail: 0, totalMs: 0 };
  stats.calls[name][ok ? 'ok' : 'fail']++;
  stats.calls[name].totalMs += ms;
  if (ok) stats.latencies.push(ms);
}

async function call(method, path, token, body, name) {
  const ctrl = new AbortController();
  const tid  = setTimeout(() => ctrl.abort(), 12000);
  const t0   = performance.now();
  try {
    const res = await fetch(`${BASE_URL}${path}`, {
      method,
      signal: ctrl.signal,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });

    const ms = performance.now() - t0;

    // Always consume body exactly once
    let data = null;
    try {
      data = await res.json();
    } catch {
      // non-JSON body — still record ok/fail based on status
    }

    const ok = res.status >= 200 && res.status < 300;
    record(name, ms, ok);

    if (!ok) {
      // surface the error message for debugging
      const msg = data?.message ?? data?.error ?? res.status;
      console.error(`[FAIL] ${name} → HTTP ${res.status}: ${msg}`);
    }

    return { ok, status: res.status, data };
  } catch (err) {
    const ms = performance.now() - t0;
    record(name, ms, false);
    console.error(`[ERR] ${name} → ${err.message}`);
    return { ok: false, status: 0, data: null, err: err.message };
  } finally {
    clearTimeout(tid);
  }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

const uid   = ()  => Math.random().toString(36).slice(2, 8);
const pick  = arr => arr[Math.floor(Math.random() * arr.length)];

function percentile(arr, p) {
  if (!arr.length) return 0;
  const s = [...arr].sort((a, b) => a - b);
  return s[Math.ceil((p / 100) * s.length) - 1];
}

async function runInBatches(items, size, fn) {
  const out = [];
  for (let i = 0; i < items.length; i += size) {
    out.push(...await Promise.all(items.slice(i, i + size).map(fn)));
  }
  return out;
}

// ── API wrappers ──────────────────────────────────────────────────────────────

const api = {
  createGuest: (i) =>
    call('POST', '/api/auth/guest', null, {
      username: `bot_${i}_${uid()}`,
      gender: i % 2,
      age: 20 + (i % 30),
    }, 'createGuest'),

  joinRoom: (token, roomId) =>
    call('POST', '/api/rooms/join', token, { roomId }, 'joinRoom'),

  leaveRoom: (token, roomId) =>
    call('POST', '/api/rooms/leave', token, { roomId }, 'leaveRoom'),

  getMembers: (token, roomId, page = 1) =>
    call('GET', `/api/rooms/${roomId}/members?page=${page}&limit=20`, token, null, 'getRoomMembers'),

  getHistory: (token, roomId, page = 1) =>
    call('GET', `/api/messages/room/${roomId}?page=${page}&limit=30`, token, null, 'getRoomMessages'),

  sendMessage: (token, roomId, text) =>
    call('POST', '/api/messages/send', token, { roomId, message: text }, 'sendRoomMessage'),
};

// ── Bot flow ──────────────────────────────────────────────────────────────────

async function runBotFlow(botIndex) {
  // ① Create guest
  const gr = await api.createGuest(botIndex);
  if (!gr.ok) return { ok: false, step: 'createGuest' };

  // Response shape: { token, user: { id, username, gender, avatar, role } }
  const token  = gr.data?.token;
  const userId = gr.data?.user?.id;     // ← .id not ._id (server returns id)

  if (!token || !userId) {
    console.error(`[bot_${botIndex}] missing token or userId in createGuest response`, gr.data);
    return { ok: false, step: 'createGuest:parse' };
  }

  const roomId = pick(ROOM_IDS);

  // ② Join room
  const jr = await api.joinRoom(token, roomId);
  // 200 = alreadyMember, 201 = joined — both are fine
  if (!jr.ok) return { ok: false, step: 'joinRoom' };

  // ③ Fetch room members (1–2 pages)
  const memberPages = Math.random() > 0.5 ? 2 : 1;
  for (let p = 1; p <= memberPages; p++) {
    await api.getMembers(token, roomId, p);
  }

  // ④ Fetch room history (1–3 pages, simulate scroll)
  const histPages = Math.floor(Math.random() * 3) + 1;
  for (let p = 1; p <= histPages; p++) {
    await api.getHistory(token, roomId, p);
  }

  // ⑤ Send messages
  for (let i = 0; i < MESSAGES_PER_BOT; i++) {
    await api.sendMessage(token, roomId, `msg_${uid()}_${i}`);
  }

  // ⑥ Leave room
  await api.leaveRoom(token, roomId);

  // ⑦ Rejoin
  await api.joinRoom(token, roomId);

  return { ok: true };
}

// ── Stats printer ─────────────────────────────────────────────────────────────

function printStats(passed, failed) {
  const dur       = (stats.endTime - stats.startTime) / 1000;
  const totalOk   = Object.values(stats.calls).reduce((s, c) => s + c.ok,   0);
  const totalFail = Object.values(stats.calls).reduce((s, c) => s + c.fail, 0);
  const avg = stats.latencies.length
    ? (stats.latencies.reduce((a, b) => a + b, 0) / stats.latencies.length).toFixed(1)
    : 0;
  const p50 = percentile(stats.latencies, 50).toFixed(1);
  const p95 = percentile(stats.latencies, 95).toFixed(1);
  const p99 = percentile(stats.latencies, 99).toFixed(1);
  const rps = dur > 0 ? (totalOk / dur).toFixed(1) : 0;

  console.log('\n=================== FLOW LOAD TEST ===================');
  console.log(`Bots completed : ${passed}`);
  console.log(`Bots failed    : ${failed}`);
  console.log(`Duration       : ${dur.toFixed(2)}s`);
  console.log(`Total OK       : ${totalOk}`);
  console.log(`Total FAILED   : ${totalFail}`);
  console.log(`Throughput     : ${rps} req/s`);
  console.log(`Avg / P50 / P95 / P99 : ${avg} / ${p50} / ${p95} / ${p99} ms`);
  console.log('\n──────── Per-Step ────────');
  const order = ['createGuest','joinRoom','getRoomMembers','getRoomMessages','sendRoomMessage','leaveRoom'];
  const keys  = [...new Set([...order, ...Object.keys(stats.calls)])];
  for (const name of keys) {
    const c = stats.calls[name];
    if (!c) continue;
    const total  = c.ok + c.fail;
    const avgMs  = (c.totalMs / total).toFixed(1);
    const errPct = ((c.fail / total) * 100).toFixed(1);
    console.log(
      `  ${name.padEnd(20)} ok:${String(c.ok).padStart(5)}  fail:${String(c.fail).padStart(4)}` +
      `  avg:${avgMs.padStart(7)}ms  err%:${errPct.padStart(5)}`
    );
  }
  console.log('=======================================================\n');
}

// ── Main ──────────────────────────────────────────────────────────────────────


async function main() {

  console.log(`Creating ${NUM_BOTS} bots...`);

  const bots = (await runInBatches(
    Array.from({ length: NUM_BOTS }, (_, i) => i),
    BOT_BATCH,
    async (i) => {
      const gr = await api.createGuest(i);

      if (!gr.ok) return null;

      return {
        token: gr.data.token,
        userId: gr.data.user.id,
        roomId: pick(ROOM_IDS)
      };
    }
  )).filter(Boolean);

  console.log(`Created ${bots.length}/${NUM_BOTS}`);

  stats.startTime = Date.now();

  // -----------------------
  // Join everybody together
  // -----------------------

  console.log("Joining...");

  await Promise.all(
    bots.map(bot =>
      api.joinRoom(bot.token, bot.roomId)
    )
  );

  // -----------------------
  // Members
  // -----------------------

  console.log("Fetching members...");

  await Promise.all(
    bots.map(bot =>
      api.getMembers(bot.token, bot.roomId, 1)
    )
  );

  // -----------------------
  // History
  // -----------------------

  console.log("Fetching history...");

  await Promise.all(
    bots.map(bot =>
      api.getHistory(bot.token, bot.roomId, 1)
    )
  );

  // -----------------------
  // Message waves
  // -----------------------

  console.log("Sending messages...");

  for (let round = 0; round < MESSAGES_PER_BOT; round++) {

    await Promise.all(
      bots.map(bot =>
        api.sendMessage(
          bot.token,
          bot.roomId,
          `msg_${uid()}_${round}`
        )
      )
    );

    console.log(
      `Wave ${round + 1}/${MESSAGES_PER_BOT} completed`
    );
  }

  // -----------------------
  // Leave
  // -----------------------

  console.log("Leaving...");

  await Promise.all(
    bots.map(bot =>
      api.leaveRoom(bot.token, bot.roomId)
    )
  );

  // -----------------------
  // Rejoin
  // -----------------------

  console.log("Rejoining...");

  await Promise.all(
    bots.map(bot =>
      api.joinRoom(bot.token, bot.roomId)
    )
  );

  stats.endTime = Date.now();

  printStats(bots.length, 0);
}

main().catch(err => {
  console.error("Fatal:", err);
  stats.endTime = Date.now();
  process.exit(1);
});