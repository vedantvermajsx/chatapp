import { useEffect, useCallback, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { useNavigate } from 'react-router-dom';
import RoomSidebar from './chat/Sidebar/RoomSidebar';
import ChatArea from './chat/ChatArea';
import { useChatState } from '../hooks/useChatState';
import { useChatSocket } from '../hooks/useChatSocket';
import { CallProvider } from '../contexts/CallContext';
import CallOverlay from './chat/Call/CallOverlay';
import { prefetchAllMessagesHandler } from '../handlers/chat.handlers';

function Chat() {
  const { user, logout } = useAuth();
  const { theme } = useTheme();
  const navigate = useNavigate();

  const chatState = useChatState(user);
  const {
    messages, setMessages,
    inputMessage, setInputMessage,
    selectedFile, setSelectedFile,
    rooms,
    joinedRooms, setJoinedRooms,
    loadingJoinedRooms,
    searchQuery, setSearchQuery,
    currentRoom, setCurrentRoom,
    currentPrivateChat, setCurrentPrivateChat,
    newRoomName, setNewRoomName,
    newRoomDesc, setNewRoomDesc,
    showCreateRoom, setShowCreateRoom,
    showMembersModal, setShowMembersModal,
    roomMembers, setRoomMembers,
    privateChats, setPrivateChats,
    loadingRooms,
    loadingPrivateChats,
    loadingMessages,
    loadingJoinRoom,
    loadingRoomMembers, setLoadingRoomMembers,
    hasMoreMessages,
    hasMoreMembers,
    showSidebar, setShowSidebar,
    messageCache,
    loadRooms,
    loadJoinedRooms,
    loadPrivateChats,
    loadRoomMembers,
    loadMoreRoomMembers,
    sendMessage,
    joinRoom,
    startPrivateChat,
    loadMoreMessages,
    unreadCounts,
    setUnreadCounts
  } = chatState;

  const handleFileSelect = (file) => {
    setSelectedFile(file);
  };

  const handleRemoveFile = () => {
    setSelectedFile(null);
  };

  const socket = useChatSocket(user, {
    currentRoom,
    currentPrivateChat,
    setCurrentPrivateChat,
    privateChats,
    setPrivateChats,
    setMessages,
    loadRooms,
    loadJoinedRooms,
    loadPrivateChats,
    messageCache,
    roomMembers,
    setRoomMembers,
    loadRoomMembers,
    setUnreadCounts
  });

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    // Load sidebar data in parallel, then background-prefetch all messages
    Promise.all([loadJoinedRooms(), loadPrivateChats()]).then(
      ([joinedRooms, privateChats]) => {
        // Fire-and-forget: prefetch new messages for every chat after app opens
        prefetchAllMessagesHandler(
          joinedRooms ?? [],
          privateChats ?? [],
          messageCache
        );
      }
    );
  }, [user, navigate]);

  const handleLeaveRoom = useCallback((roomId) => {
    setJoinedRooms(prev => prev.filter(r => r._id !== roomId));
  }, [setJoinedRooms]);

  const lastMarkedReadRef = useRef({});

  const handleChatRead = useCallback((chatKey, lastMessage) => {
    if (!socket || !chatKey || !user) return;
    if (chatKey.startsWith('private_') && lastMessage?.senderId && lastMessage?.id) {
      if (lastMarkedReadRef.current[chatKey] !== lastMessage.id) {
        lastMarkedReadRef.current[chatKey] = lastMessage.id;
        socket.emit('markRead', {
          senderId: lastMessage.senderId,
          receiverId: lastMessage.receiverId,
          messageId: lastMessage.id,
          timestamp: lastMessage.timestamp,
        });
      }
    }
    // For room chats, emit markRoomRead so server keeps RoomMessageRead in sync
    if (chatKey.startsWith('room_')) {
      const roomId = chatKey.replace('room_', '');
      if (lastMarkedReadRef.current[chatKey] !== lastMessage?.id) {
        lastMarkedReadRef.current[chatKey] = lastMessage?.id ?? null;
        socket.emit('markRoomRead', {
          roomId,
          messageId: lastMessage?.id ?? null,
          timestamp: lastMessage?.timestamp ?? new Date().toISOString()
        });
      }
    }
    setUnreadCounts(prev => {
      if (!prev[chatKey]) return prev;
      const next = { ...prev };
      delete next[chatKey];
      return next;
    });
  }, [socket, user, setUnreadCounts]);


  useEffect(() => {
    const chatKey = currentRoom?._id
      ? `room_${currentRoom._id}`
      : currentPrivateChat?.id
        ? `private_${currentPrivateChat.id}`
        : null;
    if (!chatKey) return;
    const lastNonOwnMessage = [...messages].reverse().find(m => !m.isOwn && !m.isSystemMessage) ?? null;
    handleChatRead(chatKey, lastNonOwnMessage);
  }, [currentRoom?._id, currentPrivateChat?.id, handleChatRead, messages]);

  return (
    <div className="flex w-full h-dvh overflow-hidden overflow-y-hidden relative" style={{ backgroundColor: theme.background }}>
      <RoomSidebar
        user={user}
        logout={logout}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        rooms={rooms}
        joinedRooms={joinedRooms}
        setJoinedRooms={setJoinedRooms}
        loadingJoinedRooms={loadingJoinedRooms}
        currentRoom={currentRoom}
        currentPrivateChat={currentPrivateChat}
        setCurrentPrivateChat={setCurrentPrivateChat}
        joinRoom={(roomId, roomObject) => joinRoom(roomId, socket, roomObject)}
        onRoomCreated={(room) => joinRoom(room._id, socket, room)}
        setCurrentRoom={setCurrentRoom}
        loadJoinedRooms={loadJoinedRooms}
        startPrivateChat={(user) => startPrivateChat(user, socket)}
        loadingJoinRoom={loadingJoinRoom}
        newRoomName={newRoomName}
        setNewRoomName={setNewRoomName}
        newRoomDesc={newRoomDesc}
        setNewRoomDesc={setNewRoomDesc}
        showCreateRoom={showCreateRoom}
        setShowCreateRoom={setShowCreateRoom}
        loadRooms={loadRooms}
        privateChats={privateChats}
        setPrivateChats={setPrivateChats}
        loadingRooms={loadingRooms}
        loadingPrivateChats={loadingPrivateChats}
        showSidebar={showSidebar}
        onCloseSidebar={() => setShowSidebar(false)}
        unreadCounts={unreadCounts}
      />

      <CallProvider socket={socket}>
        <CallOverlay />
        <ChatArea
          user={user}
          currentRoom={currentRoom}
          currentPrivateChat={currentPrivateChat}
          setCurrentRoom={setCurrentRoom}
          messages={messages}
          inputMessage={inputMessage}
          setInputMessage={setInputMessage}
          selectedFile={selectedFile}
          onFileSelect={handleFileSelect}
          onRemoveFile={handleRemoveFile}
          sendMessage={(e) => sendMessage(e, socket)}
          leaveRoomSocket={(roomId) => socket.emit('leaveRoom', roomId)}
          showMembersModal={showMembersModal}
          setShowMembersModal={setShowMembersModal}
          roomMembers={roomMembers}
          setRoomMembers={setRoomMembers}
          loadingRoomMembers={loadingRoomMembers}
          setLoadingRoomMembers={setLoadingRoomMembers}
          onStartPrivateChat={startPrivateChat}
          loadingMessages={loadingMessages}
          hasMoreMessages={hasMoreMessages}
          loadMoreMessages={loadMoreMessages}
          onToggleSidebar={() => setShowSidebar(s => !s)}
          loadRoomMembers={loadRoomMembers}
          hasMoreMembers={hasMoreMembers}
          loadMoreRoomMembers={loadMoreRoomMembers}
          unreadCounts={unreadCounts}
          onChatRead={handleChatRead}
          onLeaveRoom={handleLeaveRoom}
        />
      </CallProvider>
    </div>
  );
}

export default Chat;