import { useEffect, useRef } from 'react';
import io from 'socket.io-client';
import { updatePrivateChatOptimistically } from '../handlers/chat.handlers';
import { dbService } from '../services/indexedDB.service.js';

export const useChatSocket = (user, {
  currentRoom,
  currentPrivateChat,
  setCurrentPrivateChat,
  privateChats,
  setPrivateChats,
  setMessages,
  loadRooms,
  loadJoinedRooms,
  loadPrivateChats,
  messageCache,
  roomMembers,
  setRoomMembers,
  loadRoomMembers,
  setUnreadCounts
}) => {
  const socketRef = useRef(null);
  const userRef = useRef(user);
  const currentRoomRef = useRef(currentRoom);
  const currentPrivateChatRef = useRef(currentPrivateChat);
  const privateChatsRef = useRef(privateChats);
  const messageCacheRef = useRef(messageCache);
  const roomMembersRef = useRef(roomMembers);
  const loadRoomsRef = useRef(loadRooms);
  const loadJoinedRoomsRef = useRef(loadJoinedRooms);
  const loadPrivateChatsRef = useRef(loadPrivateChats);

  useEffect(() => { userRef.current = user; }, [user]);
  useEffect(() => { currentRoomRef.current = currentRoom; }, [currentRoom]);
  useEffect(() => { currentPrivateChatRef.current = currentPrivateChat; }, [currentPrivateChat]);
  useEffect(() => { privateChatsRef.current = privateChats; }, [privateChats]);
  useEffect(() => { messageCacheRef.current = messageCache; }, [messageCache]);
  useEffect(() => { roomMembersRef.current = roomMembers; }, [roomMembers]);
  useEffect(() => { loadRoomsRef.current = loadRooms; }, [loadRooms]);
  useEffect(() => { loadJoinedRoomsRef.current = loadJoinedRooms; }, [loadJoinedRooms]);
  useEffect(() => { loadPrivateChatsRef.current = loadPrivateChats; }, [loadPrivateChats]);


  useEffect(() => {
    if (!user) return;
    const token = localStorage.getItem('token');
    if (!socketRef.current) {
      socketRef.current = io(import.meta.env.VITE_LOAD_BALENCER_URL, {
        transports: ['websocket', 'polling'],
        withCredentials: true,
        perMessageDeflate: true,
        reconnection: true,
        reconnectionAttempts: 1000,
        reconnectionDelay: 3000,
        reconnectionDelayMax: 5000,
        randomizationFactor: 0.5,
        auth: {
          token: token
        }
      });
    }
  }, [user]);

  useEffect(() => {
    if (!socketRef.current) return;
    const socket = socketRef.current;

    const handleConnect = () => {
      const currentUser = userRef.current;
      if (currentUser) {
        socket.emit('join', {
          userId: currentUser._id || currentUser.id,
          role: currentUser.role,
          username: currentUser.username,
          gender: currentUser.gender
        });
      }
    };

    const handleNewMessage = async (msg) => {
      const currentUser = userRef.current;
      const messageCache = messageCacheRef.current;

      const isOwnMessage = msg.userId === (currentUser?._id || currentUser?.id);
      // Is the user currently viewing this room?
      const isActiveRoom = String(currentRoomRef.current?._id) === String(msg.roomId);

      const newMessage = {
        id: msg?._id || msg?.id,
        username: msg?.username,
        text: msg?.text,
        isOwn: isOwnMessage,
        timestamp: msg?.timestamp || new Date().toISOString(),
        gender: msg?.gender,
        avatar: msg?.avatar || null,
        isOnline: msg?.isOnline,
        lastSeen: msg?.lastSeen,
        media: msg?.media || null,
        isPending: false,
        ...(msg?.isSystemMessage && {
          isSystemMessage: true,
          systemType: msg.systemType || null,
        }),
      };

      // Only push into the visible message list if this is the active room
      if (isActiveRoom) {
        setMessages((prev) => {
          if (msg._id && prev.some(m => String(m.id) === String(msg._id))) return prev;
          const existingOptimisticIndex = prev.findIndex(m =>
            m.isOwn && m.isPending && m.text === newMessage.text && (!!m.media === !!newMessage.media)
          );
          if (isOwnMessage && existingOptimisticIndex !== -1) {
            const newMessages = [...prev];
            newMessages[existingOptimisticIndex] = newMessage;
            return newMessages;
          }
          if ((msg._id || msg.id) && prev.some(m => m.id === (msg._id || msg.id))) return prev;
          return [...prev, newMessage];
        });
      }

      // Always update the in-memory cache for this room
      const cacheKey = `room_${msg.roomId}`;
      if (messageCache.current[cacheKey]) {
        const prevMessages = messageCache.current[cacheKey].messages;
        const existingOptimisticIndex = prevMessages.findIndex(m =>
          m.isOwn && m.isPending && m.text === newMessage.text && (!!m.media === !!newMessage.media)
        );

        const alreadyInCache = prevMessages.some((m) => String(m.id) === String(newMessage.id));
        let newCacheMessages;
        if (!alreadyInCache) {
          if (isOwnMessage && existingOptimisticIndex !== -1) {
            newCacheMessages = [...prevMessages];
            newCacheMessages[existingOptimisticIndex] = newMessage;
          } else {
            newCacheMessages = [...prevMessages, newMessage];
          }
        }

        if (newCacheMessages && newCacheMessages !== prevMessages) {
          messageCache.current[cacheKey] = {
            ...messageCache.current[cacheKey],
            messages: newCacheMessages
          };
        }
      }

      await dbService.addMessage(cacheKey, newMessage);

      // If this is the active room, tell server the messages are read
      if (isActiveRoom && !msg.isSystemMessage) {
        socket.emit('markRoomRead', {
          roomId: msg.roomId,
          messageId: newMessage.id,
          timestamp: newMessage.timestamp
        });
      }

      // Increment unread badge if user is NOT viewing this room and it's not their own message
      if (!isOwnMessage && !isActiveRoom && !msg.isSystemMessage) {
        setUnreadCounts(prev => ({ ...prev, [cacheKey]: (prev[cacheKey] || 0) + 1 }));
      }
    };

    const handleNewPrivateMessage = async (msg) => {
      const currentUser = userRef.current;
      const currentPrivateChat = currentPrivateChatRef.current;
      const privateChats = privateChatsRef.current;
      const messageCache = messageCacheRef.current;

      const currentUserId = currentUser?._id || currentUser?.id;
      const otherUserId = msg.senderId === currentUserId ? msg.receiverId : msg.senderId;
      const isOwnMessage = msg.senderId === (currentUser?._id || currentUser?.id);

      let otherUser = privateChats.find(c => c.otherUser.id === otherUserId)?.otherUser;
      if (!otherUser) {
        otherUser = {
          id: otherUserId,
          username: msg.senderUsername || msg.username || 'Unknown',
          role: (msg.senderModel?.toLowerCase() || 'user'),
          avatar: msg.avatar || null,
          isOnline: msg.isOnline,
          lastSeen: msg.lastSeen
        };
      }

      updatePrivateChatOptimistically(privateChats, setPrivateChats, otherUser, msg.content);

      const cacheKey = `private_${otherUserId}`;
      const newMessageObj = {
        id: msg._id || msg.id,
        senderId: msg.senderId,
        receiverId: msg.receiverId,
        username: msg.senderUsername || msg.username,
        text: msg.content,
        isOwn: isOwnMessage,
        timestamp: msg.timestamp || new Date().toISOString(),
        gender: msg.gender,
        avatar: msg.avatar || null,
        isOnline: msg.isOnline,
        lastSeen: msg.lastSeen,
        media: msg.media || null,
        isPending: false,
        ...(msg?.isSystemMessage && {
          isSystemMessage: true,
          systemType: msg.systemType || null,
        }),
      };

      if (messageCache.current[cacheKey]) {
        const prevMessages = messageCache.current[cacheKey].messages;
        const existingOptimisticIndex = prevMessages.findIndex(m =>
          m.isOwn && m.isPending && m.text === newMessageObj.text && (!!m.media === !!newMessageObj.media)
        );

        let newCacheMessages;
        if (isOwnMessage && existingOptimisticIndex !== -1) {
          newCacheMessages = [...prevMessages];
          newCacheMessages[existingOptimisticIndex] = newMessageObj;
        } else {
          const already = prevMessages.some((m) => String(m.id) === String(newMessageObj.id));
          newCacheMessages = already ? prevMessages : [...prevMessages, newMessageObj];
        }

        if (newCacheMessages !== prevMessages) {
          messageCache.current[cacheKey] = {
            ...messageCache.current[cacheKey],
            messages: newCacheMessages
          };
        }
      } else {
        messageCache.current[cacheKey] = {
          messages: [newMessageObj],
          hasMore: false,
          timestamp: Date.now()
        };
      }

      // Only push into visible list if user is currently viewing this conversation
      const isActiveChat = currentPrivateChatRef.current?.id === otherUserId;

      if (isActiveChat) {
        setMessages((prev) => {
          if (msg._id && prev.some(m => String(m.id) === String(msg._id))) return prev;
          const existingOptimisticIndex = newMessageObj.isSystemMessage ? -1 : prev.findIndex(m =>
            m.isOwn && m.isPending && m.text === newMessageObj.text && (!!m.media === !!newMessageObj.media)
          );
          if (isOwnMessage && existingOptimisticIndex !== -1) {
            const newMessages = [...prev];
            newMessages[existingOptimisticIndex] = newMessageObj;
            return newMessages;
          }
          if ((msg._id || msg.id) && prev.some(m => m.id === (msg._id || msg.id))) return prev;
          return [...prev, newMessageObj];
        });
      }
      
      await dbService.addMessage(cacheKey, newMessageObj);

    };

    const handleReadReceipt = async ({ senderId, receiverId, messageId, lastSeenAt }) => {
      const currentPrivateChat = currentPrivateChatRef.current;
      const messageCache = messageCacheRef.current;
      const cacheKey = `private_${receiverId}`;

      // Always update the cache so isSeen is correct when user opens the chat later
      if (messageCache.current[cacheKey]) {
        const prevMessages = messageCache.current[cacheKey].messages;
        const updatedMessages = prevMessages.map(msg => {
          if (!msg.isOwn || msg.isSystemMessage) return msg;
          if (msg.id === messageId) return { ...msg, isSeen: true, seenAt: lastSeenAt };
          if (msg.isSeen) return { ...msg, isSeen: false, seenAt: null };
          return msg;
        });
        const changed = updatedMessages.filter((msg, i) => msg !== prevMessages[i]);
        if (changed.length) {
          messageCache.current[cacheKey] = {
            ...messageCache.current[cacheKey],
            messages: updatedMessages,
          };
          changed.forEach(msg => dbService.addMessage(cacheKey, msg));
        }
      }

      // Only update the visible message list if user is currently in this chat
      const isActiveChat = currentPrivateChat && String(currentPrivateChat.id) === String(receiverId);
      if (!isActiveChat) return;

      setMessages(prev => {
        const updated = prev.map(msg => {
          if (!msg.isOwn || msg.isSystemMessage) return msg;
          if (msg.id === messageId) return { ...msg, isSeen: true, seenAt: lastSeenAt };
          if (msg.isSeen) return { ...msg, isSeen: false, seenAt: null };
          return msg;
        });

        const changed = updated.filter((msg, i) => msg !== prev[i]);
        if (changed.length) {
          changed.forEach(msg => dbService.addMessage(cacheKey, msg));
        }

        return updated;
      });
    };

    const handleNewRoom = () => { loadRoomsRef.current?.(); if (loadJoinedRoomsRef.current) loadJoinedRoomsRef.current(); };

    const handleUserOnline = ({ userId }) => {
      const roomMembers = roomMembersRef.current;
      const privateChats = privateChatsRef.current;
      const currentPrivateChat = currentPrivateChatRef.current;

      if (roomMembers) {
        setRoomMembers(prev => (prev || []).map(member =>
          String(member.id || member._id) === String(userId) ? { ...member, isOnline: true } : member
        ));
      }

      setPrivateChats(prev => (prev || []).map(chat =>
        String(chat.otherUser.id || chat.otherUser._id) === String(userId)
          ? { ...chat, otherUser: { ...chat.otherUser, isOnline: true } }
          : chat
      ));

      if (currentPrivateChat && String(currentPrivateChat.id || currentPrivateChat._id) === String(userId)) {
        setCurrentPrivateChat(prev => prev ? { ...prev, isOnline: true } : prev);
      }
    };

    const handleUserOffline = ({ userId }) => {
      const roomMembers = roomMembersRef.current;
      const privateChats = privateChatsRef.current;
      const currentPrivateChat = currentPrivateChatRef.current;

      if (roomMembers) {
        setRoomMembers(prev => (prev || []).map(member =>
          String(member.id || member._id) === String(userId) ? { ...member, isOnline: false } : member
        ));
      }

      setPrivateChats(prev => (prev || []).map(chat =>
        String(chat.otherUser.id || chat.otherUser._id) === String(userId)
          ? { ...chat, otherUser: { ...chat.otherUser, isOnline: false, lastSeen: new Date().toISOString() } }
          : chat
      ));

      if (currentPrivateChat && String(currentPrivateChat.id || currentPrivateChat._id) === String(userId)) {
        setCurrentPrivateChat(prev => prev ? { ...prev, isOnline: false, lastSeen: new Date().toISOString() } : prev);
      }
    };

    const handleRoomReadAck = ({ roomId }) => {
      // Server confirmed the read — ensure badge is cleared (idempotent)
      setUnreadCounts(prev => {
        const key = `room_${roomId}`;
        if (!prev[key]) return prev;
        const next = { ...prev };
        delete next[key];
        return next;
      });
    };

    const handleUnreadUpdate = ({ chatKey }) => {
      if (!chatKey) return;
      setUnreadCounts(prev => ({ ...prev, [chatKey]: (prev[chatKey] || 0) + 1 }));
    };

    socket.on('connect', handleConnect);
    socket.on('connect_error', (error) => console.error('Socket connection error:', error));
    socket.on('disconnect', (reason) => console.log('Socket disconnected:', reason));
    socket.on('newMessage', handleNewMessage);
    socket.on('newPrivateMessage', handleNewPrivateMessage);
    socket.on('newRoom', handleNewRoom);
    socket.on('userOnline', handleUserOnline);
    socket.on('userOffline', handleUserOffline);
    socket.on('readReceipt', handleReadReceipt);
    socket.on('roomReadAck', handleRoomReadAck);
    socket.on('unreadUpdate', handleUnreadUpdate);

    if (socket.connected) { handleConnect(); }

    return () => {
      socket.off('connect', handleConnect);
      socket.off('connect_error');
      socket.off('disconnect');
      socket.off('newMessage', handleNewMessage);
      socket.off('newPrivateMessage', handleNewPrivateMessage);
      socket.off('newRoom', handleNewRoom);
      socket.off('userOnline', handleUserOnline);
      socket.off('userOffline', handleUserOffline);
      socket.off('readReceipt', handleReadReceipt);
      socket.off('roomReadAck', handleRoomReadAck);
      socket.off('unreadUpdate', handleUnreadUpdate);
    };
  }, [setMessages, setPrivateChats, setRoomMembers, setUnreadCounts]);

  return socketRef.current;
};