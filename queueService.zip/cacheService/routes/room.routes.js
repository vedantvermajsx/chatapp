import express from 'express';
import { addRoom } from '../controllers/room/addRoom.controller.js';
import { getAllRooms } from '../controllers/room/getAllRooms.controller.js';
import { checkExists } from '../controllers/room/checkExists.controller.js';
import { hasMember } from '../controllers/room/hasMember.controller.js';
import { getAdmin } from '../controllers/room/getAdmin.controller.js';
import { refreshRoom } from '../controllers/room/refreshRoom.controller.js';
import { getRoomById } from '../controllers/room/getRoomById.controller.js';
import { getRoomByName } from '../controllers/room/getRoomByName.controller.js';
import { getRoomsByUser } from '../controllers/room/getRoomsByUser.controller.js';
import { getMembers } from '../controllers/room/getMembers.controller.js';
import { invalidateMembers } from '../controllers/room/invalidateMembers.controller.js';
import { deleteRoom } from '../controllers/room/deleteRoom.controller.js';
import { getMemberIds } from '../controllers/room/getMemberIds.controller.js';
import { addRoomMember } from '../controllers/room/addRoomMember.controller.js';
import { removeRoomMember } from '../controllers/room/removeRoomMember.controller.js';
import { markRoomDeleted } from '../controllers/room/markRoomDeleted.controller.js';

const router = express.Router();

router.post('/', addRoom);
router.get('/', getAllRooms);
router.get('/:id/exists', checkExists);
router.get('/:id/hasMember/:userId', hasMember);
router.get('/:id/admin', getAdmin);
router.post('/:id/refresh', refreshRoom);
router.get('/:id', getRoomById);
router.get('/name/:name', getRoomByName);
router.get('/user/:userId', getRoomsByUser);
router.get('/:id/members', getMembers);
router.post('/:id/invalidate-members', invalidateMembers);
router.delete('/:id', deleteRoom);
router.get('/:id/memberIds', getMemberIds);
router.post('/:id/members/add', addRoomMember);
router.post('/:id/members/remove', removeRoomMember);
router.post('/:id/mark-deleted', markRoomDeleted);

export default router;
