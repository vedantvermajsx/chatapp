import http from 'http';

const BASE_URL = 'http://127.0.0.1:4000';
const ROOM_ID = '6a343fb51c37e4d5a62ad078';

const NUM_BOTS = 500;
const MESSAGES_PER_BOT = 20;

// LIMITS
const BOT_CREATE_BATCH = 25;
const ROOM_JOIN_BATCH = 50;
const MESSAGE_BATCH = 100;

// KEEP-ALIVE AGENT
const agent = new http.Agent({
  keepAlive: true,
  maxSockets: 1000,
  maxFreeSockets: 100,
  timeout: 60000,
});

const stats = {
  botsCreated: 0,
  botCreateFailed: 0,

  roomJoined: 0,
  roomJoinFailed: 0,

  messagesSent: 0,
  messagesFailed: 0,

  totalResponseTime: 0,
  latencies: [],

  startTime: 0,
  endTime: 0,
};

// ------------------------
// HELPERS
// ------------------------

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function percentile(arr, p) {
  if (!arr.length) return 0;

  const sorted = [...arr].sort((a, b) => a - b);

  const index = Math.ceil(
    (p / 100) * sorted.length
  ) - 1;

  return sorted[index];
}

async function fetchWithTimeout(
  url,
  options = {},
  timeout = 10000
) {
  const controller = new AbortController();

  const timeoutId = setTimeout(() => {
    controller.abort();
  }, timeout);

  try {
    return await fetch(url, {
      ...options,
      agent,
      signal: controller.signal,
    });
  } finally {
    clearTimeout(timeoutId);
  }
}

async function runInBatches(
  items,
  batchSize,
  fn
) {
  const results = [];

  for (
    let i = 0;
    i < items.length;
    i += batchSize
  ) {
    const batch = items.slice(
      i,
      i + batchSize
    );

    const batchResults =
      await Promise.all(
        batch.map(fn)
      );

    results.push(...batchResults);
  }

  return results;
}

// ------------------------
// API CALLS
// ------------------------

async function createGuest(botIndex) {
  const username = `bot_${botIndex}_${Date.now()}`;

  const res = await fetchWithTimeout(
    `${BASE_URL}/api/auth/guest`,
    {
      method: 'POST',
      headers: {
        'Content-Type':
          'application/json',
      },
      body: JSON.stringify({
        username,
        gender: botIndex % 2,
        age: 20 + (botIndex % 30),
      }),
    }
  );

  if (!res.ok) {
    throw new Error(
      `Guest create failed: ${res.status}`
    );
  }

  return res.json();
}

async function joinRoom(token, roomId) {
  const res = await fetchWithTimeout(
    `${BASE_URL}/api/rooms/join`,
    {
      method: 'POST',
      headers: {
        'Content-Type':
          'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        roomId,
      }),
    }
  );

  if (!res.ok) {
    throw new Error(
      `Join failed: ${res.status}`
    );
  }

  return res.json();
}

async function sendMessage(
  token,
  roomId,
  message
) {
  const start = performance.now();

  const res = await fetchWithTimeout(
    `${BASE_URL}/api/messages/send`,
    {
      method: 'POST',
      headers: {
        'Content-Type':
          'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        roomId,
        message,
      }),
    }
  );

  const latency =
    performance.now() - start;

  stats.totalResponseTime += latency;

  stats.latencies.push(latency);

  if (!res.ok) {
    throw new Error(
      `Send failed: ${res.status}`
    );
  }

  return res.json();
}

// ------------------------
// STATS
// ------------------------

function printFinalStats() {
  const durationMs =
    stats.endTime - stats.startTime;

  const durationSec = durationMs / 1000;

  const avgLatency =
    stats.messagesSent > 0
      ? (
          stats.totalResponseTime /
          stats.messagesSent
        ).toFixed(2)
      : 0;

  const throughput =
    durationSec > 0
      ? (
          stats.messagesSent /
          durationSec
        ).toFixed(2)
      : 0;

  const p50 = percentile(
    stats.latencies,
    50
  ).toFixed(2);

  const p95 = percentile(
    stats.latencies,
    95
  ).toFixed(2);

  const p99 = percentile(
    stats.latencies,
    99
  ).toFixed(2);

  console.log(
    '\n================ LOAD TEST STATS ================'
  );

  console.log(
    `Bots Created Successfully : ${stats.botsCreated}`
  );

  console.log(
    `Bot Creation Failed       : ${stats.botCreateFailed}`
  );

  console.log(
    `Rooms Joined Successfully : ${stats.roomJoined}`
  );

  console.log(
    `Room Join Failed          : ${stats.roomJoinFailed}`
  );

  console.log(
    `Messages Sent Successfully: ${stats.messagesSent}`
  );

  console.log(
    `Messages Failed           : ${stats.messagesFailed}`
  );

  console.log(
    `Total Messages            : ${
      stats.messagesSent +
      stats.messagesFailed
    }`
  );

  console.log(
    `Test Duration             : ${durationSec.toFixed(
      2
    )} sec`
  );

  console.log(
    `Average Latency           : ${avgLatency} ms`
  );

  console.log(
    `P50 Latency               : ${p50} ms`
  );

  console.log(
    `P95 Latency               : ${p95} ms`
  );

  console.log(
    `P99 Latency               : ${p99} ms`
  );

  console.log(
    `Throughput                : ${throughput} msg/sec`
  );

  console.log(
    '=================================================\n'
  );
}

// ------------------------
// MAIN
// ------------------------

async function main() {
  console.log(
    '\nStarting load test...\n'
  );

  // ------------------------
  // CREATE BOTS
  // ------------------------

  console.log(
    `Creating ${NUM_BOTS} bots...`
  );

  const botIndexes = Array.from(
    { length: NUM_BOTS },
    (_, i) => i
  );

  const botResults =
    await runInBatches(
      botIndexes,
      BOT_CREATE_BATCH,
      async i => {
        try {
          const bot =
            await createGuest(i);

          stats.botsCreated++;

          if (
            stats.botsCreated % 25 ===
            0
          ) {
            console.log(
              `Created ${stats.botsCreated}/${NUM_BOTS}`
            );
          }

          return bot;
        } catch (err) {
          stats.botCreateFailed++;

          console.error(
            `Bot create failed:`,
            err.message
          );

          return null;
        }
      }
    );

  const bots =
    botResults.filter(Boolean);

  console.log(
    `\nBots ready: ${bots.length}\n`
  );

  // ------------------------
  // JOIN ROOMS
  // ------------------------

  console.log('Joining rooms...');

  await runInBatches(
    bots,
    ROOM_JOIN_BATCH,
    async bot => {
      try {
        await joinRoom(
          bot.token,
          ROOM_ID
        );

        stats.roomJoined++;
      } catch (err) {
        stats.roomJoinFailed++;

        console.error(
          `Join failed:`,
          err.message
        );
      }
    }
  );

  console.log(
    `Rooms joined: ${stats.roomJoined}\n`
  );

  // ------------------------
  // START BENCHMARK
  // ------------------------

  stats.startTime = Date.now();

  console.log(
    'Starting message benchmark...\n'
  );

  // TRUE CONCURRENCY
  const allTasks = [];

  for (const bot of bots) {
    for (
      let i = 0;
      i < MESSAGES_PER_BOT;
      i++
    ) {
      allTasks.push({
        token: bot.token,
        message: `Hello from ${bot.user.username} #${
          i + 1
        }`,
      });
    }
  }

  console.log(
    `Prepared ${allTasks.length} messages`
  );

  await runInBatches(
    allTasks,
    MESSAGE_BATCH,
    async task => {
      try {
        await sendMessage(
          task.token,
          ROOM_ID,
          task.message
        );

        stats.messagesSent++;

        if (
          stats.messagesSent % 500 ===
          0
        ) {
          console.log(
            `Sent ${stats.messagesSent}`
          );
        }
      } catch (err) {
        stats.messagesFailed++;

        console.error(
          `Message failed:`,
          err.message
        );
      }
    }
  );

  stats.endTime = Date.now();

  printFinalStats();
}

main().catch(err => {
  console.error(err);

  stats.endTime = Date.now();

  printFinalStats();
});