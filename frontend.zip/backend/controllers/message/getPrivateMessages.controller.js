import { messageCacheClient } from '../../database/messageCacheClient.js';
import ConversationRead from '../../models/conversationRead.model.js';

export const getPrivateMessages = async (req, res) => {
  try {
    const { otherUserId } = req.params;
    const { limit = 20, before, after } = req.query;
    const { user } = req;
    const userId = user.id;

    const { messages, hasMore } = await messageCacheClient.getPrivateMessages(userId, otherUserId, {
      limit: parseInt(limit, 10),
      before: before || undefined,
      after: after || undefined,
    });

    const recentMessageSeen = await ConversationRead.findOne({ senderId: userId, receiverId: otherUserId });

    if (!messages.length) {
      return res.status(200).json({ messages: [], hasMore: false });
    }

    console.log(messages);

    const formattedMessages = messages.map((msg) => {
      return {
        _id: msg.id,
        id:msg.id,
        username: msg.username,
        text: msg.content,
        isOwn: msg.senderId === userId,
        timestamp: msg.timestamp,
        media: msg.media || null,
        isSeen: (recentMessageSeen && msg.id===recentMessageSeen.messageId) || false,
      };
    });

    res.status(200).json({ messages: formattedMessages, hasMore });
  } catch (error) {
    console.error('Error getting private messages:', error);
    res.status(500).json({ message: 'Failed to get messages', error: error.message });
  }
};