import mongoose from 'mongoose';

const messageSchema = new mongoose.Schema(
  {
    _id: { type: String, required: true },

    senderId: { type: String, required: true },

    receiverId: { type: String, default: null },

    roomId: { type: String, default: null },

    content: { type: String, default: '' },

    isSystemMessage: {
      type: Boolean,
      default: false,
      immutable: true
    },

    media: {
      type: {
        type: String,
        enum: ['image', 'video', 'gif', 'audio'],
        default: null
      },
      url: {
        type: String,
        default: null
      }
    },

    timestamp: {
      type: Date,
      default: Date.now
    },

    deletedFor: [
      {
        type: String,
        ref:'User'
      }
    ]
  },
  {
    versionKey: false
  }
);

messageSchema.index({ roomId: 1, timestamp: -1 });

messageSchema.index({ senderId: 1, receiverId: 1, timestamp: -1 });
messageSchema.index({ receiverId: 1, senderId: 1, timestamp: -1 });

export default mongoose.models.Message ||
  mongoose.model('Message', messageSchema);