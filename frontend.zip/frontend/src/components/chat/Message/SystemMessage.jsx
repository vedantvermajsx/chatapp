import { useTheme } from "../../../contexts/ThemeContext";
import { useNeumorphism } from "../../../hooks/useNeumorphism";

const SystemMessage = ({ msg }) => {
    const { theme } = useTheme();
    const { getShadow } = useNeumorphism();
    return (
        <div className="flex justify-center my-6">
            <span
                className="text-xs px-6 py-3 rounded-2xl font-semibold flex items-center gap-2 border"
                style={{
                    backgroundColor: theme.background,
                    borderColor: theme.isLight ? '#e2e8f0' : '#4a5568',
                    color: theme.otherMessageText,
                    boxShadow: getShadow(theme.isLight, false, 2, 5)
                }}
            >
                {msg.text}
            </span>
        </div>
    );
};

export default SystemMessage;