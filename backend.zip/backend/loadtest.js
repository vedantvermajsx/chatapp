const BASE_URL = 'http://localhost:4000';
const ROOM_ID = '6a343fb51c37e4d5a62ad078';

const NUM_BOTS = 150;
const MESSAGES_PER_BOT = 20;

const stats = {
  botsCreated: 0,
  botCreateFailed: 0,

  roomJoined: 0,
  roomJoinFailed: 0,

  messagesSent: 0,
  messagesFailed: 0,

  totalResponseTime: 0,

  startTime: 0,
  endTime: 0,
};

async function createGuest(botIndex) {
  const username = `bot_${botIndex}_${Date.now()}`;

  const res = await fetch(`${BASE_URL}/api/auth/guest`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      username,
      gender: botIndex % 2,
      age: 20 + (botIndex % 30),
    }),
  });

  if (!res.ok) {
   
    console.log(res);
  }

  return res.json();
}

async function joinRoom(token, roomId) {
  const res = await fetch(`${BASE_URL}/api/rooms/join`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({ roomId }),
  });

  if(!res.ok) console.log("failed to join");

  return res.json();
}

async function sendMessage(token, roomId, message) {
  const start = Date.now();

  const res = await fetch(`${BASE_URL}/api/messages/send`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({
      roomId,
      message,
    }),
  });

  const latency = Date.now() - start;

  stats.totalResponseTime += latency;

  if (!res.ok) {
    throw new Error(
      `Failed to send message: ${res.status}`
    );
  }

  return res.json();
}

function printFinalStats() {
  const durationMs =
    stats.endTime - stats.startTime;

  const durationSec = durationMs / 1000;

  const avgResponseTime =
    stats.messagesSent > 0
      ? (
          stats.totalResponseTime /
          stats.messagesSent
        ).toFixed(2)
      : 0;

  const throughput =
    durationSec > 0
      ? (
          stats.messagesSent / durationSec
        ).toFixed(2)
      : 0;

  console.log(
    '\n================ LOAD TEST STATS ================'
  );

  console.log(
    `Bots Created Successfully : ${stats.botsCreated}`
  );

  console.log(
    `Bot Creation Failed       : ${stats.botCreateFailed}`
  );

  console.log(
    `Rooms Joined Successfully : ${stats.roomJoined}`
  );

  console.log(
    `Room Join Failed          : ${stats.roomJoinFailed}`
  );

  console.log(
    `Messages Sent Successfully: ${stats.messagesSent}`
  );

  console.log(
    `Messages Failed           : ${stats.messagesFailed}`
  );

  console.log(
    `Total Messages            : ${stats.messagesSent + stats.messagesFailed}`
  );

  console.log(
    `Test Duration             : ${durationSec.toFixed(
      2
    )} sec`
  );

  console.log(
    `Average Message Latency   : ${avgResponseTime} ms`
  );

  console.log(
    `Message Throughput        : ${throughput} msg/sec`
  );

  console.log(
    '=================================================\n'
  );
}

async function main() {
  console.log('Starting load test...');
  console.log(
    `Creating ${NUM_BOTS} guest users...`
  );

  // CREATE BOTS CONCURRENTLY
  const botPromises = Array.from(
    { length: NUM_BOTS },
    async (_, i) => {
      try {
        const authData = await createGuest(i);

        stats.botsCreated++;

        if (stats.botsCreated % 10 === 0) {
          console.log(
            `Created ${stats.botsCreated}/${NUM_BOTS} bots`
          );
        }

        return authData;
      } catch (err) {
        stats.botCreateFailed++;

        console.error(
          `Error creating bot ${i}:`,
          err.message
        );

        return null;
      }
    }
  );

  const bots = (
    await Promise.all(botPromises)
  ).filter(Boolean);

  console.log('All bots created!');

  console.log('Joining room...');

  // JOIN ROOMS CONCURRENTLY
  await Promise.all(
    bots.map(async bot => {
      try {
        await joinRoom(bot.token, ROOM_ID);

        stats.roomJoined++;
      } catch (err) {
        stats.roomJoinFailed++;

        console.error(
          'Error joining room:',
          err.message
        );
      }
    })
  );

  console.log('All bots joined the room!');

  // START TIMER ONLY FOR MESSAGE BENCHMARK
  stats.startTime = Date.now();

  console.log('Starting message spam...');

  const sendMessages = async bot => {
    for (
      let i = 0;
      i < MESSAGES_PER_BOT;
      i++
    ) {
      try {
        await sendMessage(
          bot.token,
          ROOM_ID,
          `Hello from ${bot.user.username}! Message #${
            i + 1
          }`
        );

        stats.messagesSent++;

        if (
          stats.messagesSent % 100 === 0
        ) {
          console.log(
            `Sent ${stats.messagesSent} messages`
          );
        }
      } catch (err) {
        stats.messagesFailed++;

        console.error(
          'Error sending message:',
          err.message
        );
      }
    }
  };

  // ALL BOTS SEND CONCURRENTLY
  const workers = bots.map(bot =>
    sendMessages(bot)
  );

  await Promise.all(workers);

  stats.endTime = Date.now();

  printFinalStats();
}

main().catch(err => {
  console.error(err);

  stats.endTime = Date.now();

  printFinalStats();
});