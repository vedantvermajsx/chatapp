import http from "k6/http";
import { check, sleep } from "k6";

const BASE_URL = "http://localhost:4000";

const ROOM_ID = "6a59ea8d4721dbddd69321a1";

const TOTAL_USERS = 100;
const MESSAGES_PER_USER = 20;


export const options = {
    vus: TOTAL_USERS,
    iterations: TOTAL_USERS,
};


export function setup() {

    let users = [];

    console.log("Creating users...");

    for (let i = 0; i < TOTAL_USERS; i++) {

        const payload = JSON.stringify({
            username: `(id_ddfdd)_${i}`,
            gender:0
        });


        const res = http.post(
            `${BASE_URL}/api/auth/guest`,
            payload,
            {
                headers: {
                    "Content-Type": "application/json",
                },
            }
        );


        console.log(`Guest ${i} response status: ${res.status}`);
        // console.log(`Guest ${i} response body: ${res.body}`);
        
        check(res, {
            "guest created": (r) =>
                r.status === 200 || r.status === 201,
        });


        const data = res.json();

        console.log("guest "+i);


        users.push({
            id: data.user._id,
            token: data.token,
        });
    }


    console.log(`Created ${users.length} users`);

    return users;
}



export default function(users) {

    const user = users[__VU - 1];


    for (let i = 0; i < MESSAGES_PER_USER; i++) {


        const payload = JSON.stringify({

            roomId: ROOM_ID,

            message:
                `Load test message ${i + 1} from ${user.id}`,

            media: null,

            isSystemMessage: false,

            systemType: null
        });



        const res = http.post(
            `${BASE_URL}/api/messages/send`,
            payload,
            {
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${user.token}`,
                },
            }
        );


        check(res, {
            "message sent": (r) =>
                r.status === 201,
        });


        sleep(0.05);
    }
}