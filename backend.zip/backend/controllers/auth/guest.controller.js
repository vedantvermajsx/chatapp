import { generateGuestId } from '../../utils/idGenerator.js';
import { handleAuthSuccess } from './auth.helper.js';
import { isUsernameTaken } from './usernameTaken.js';
import { enqueueGuestRegistration } from '../../utils/queueClient.js';
import { getDefaultAvatar } from '../../utils/getDefaultAvtar.js';
import { USERNAME_CHARS_REGEX } from '../../utils/validators.js';

export async function createGuest(req, res) {
  try {
    const { username, gender, publicKey } = req.body;

    const refactoredUsername = username?.trim().toLowerCase();

   //console.log(username,gender);

    if (!refactoredUsername) {
      return res.status(400).json({ message: 'Username is required' });
    }
    if(gender===undefined || gender===null || gender<0 || gender>2){
         return res.status(400).json({message:"Invalid gender !"});
    }

    if (refactoredUsername.length < 2 || refactoredUsername.length > 30) {
      return res.status(400).json({ message: 'Username must be 2–30 characters' });
    }

    if (!USERNAME_CHARS_REGEX.test(refactoredUsername)) {
      return res.status(400).json({ message: 'Username can only contain letters, numbers, and underscores' });
    }

    const taken = await isUsernameTaken(refactoredUsername);
    if (taken) {
      return res.status(400).json({ message: 'Username already taken' });
    }

    const guestId = generateGuestId();
    const defaultAvatar = getDefaultAvatar(gender);

    const guestData = {
      _id: guestId,
      username: refactoredUsername,
      gender: Number(gender),
      avatar: defaultAvatar,
      publicKey: publicKey || null,
      isOnline: true,
      lastSeen: new Date(),
    };

    enqueueGuestRegistration(guestData);

    await handleAuthSuccess(res, { _id: guestId, ...guestData }, 'guest');
  } catch (err) {
    console.error('[createGuest] unexpected error:', err.message);
    if (err.message?.startsWith('seedUser failed')) {
      return res.status(503).json({ message: 'Cache service unavailable, please retry' });
    }
    res.status(500).json({ message: err.message });
  }
}