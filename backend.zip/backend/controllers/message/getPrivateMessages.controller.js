import { messageCacheClient } from '../../database/messageCacheClient.js';
import lastReadCacheClient from '../../database/lastReadCacheClient.js';
import userCacheClient from '../../database/userCacheClient.js';
import { _addQualities } from '../../utils/addQualities.js';
import { getDefaultAvatar } from '../../utils/getDefaultAvtar.js';
import { applyUnreadOnFetch } from '../../utils/applyUnreadOnFetch.js';
import { compact } from '../../utils/compact.js';

function deletedUserFallback(msg) {
  const gender = msg.gender ?? null;
  return {
    username: msg.username || msg.senderUsername || 'Deleted User',
    avatar: msg.avatar || getDefaultAvatar(gender ?? 0),
    gender,
  };
}



export const getPrivateMessages = async (req, res) => {
  try {
    const { otherUserId } = req.params;
    const { limit = 20, before, after } = req.query;
    const { user } = req;
    const userId = user._id;
    const limitInt = parseInt(limit);
    const [messagesResult, lastReadResult] = await Promise.allSettled([
      messageCacheClient.getPrivateMessages(
        userId,
        otherUserId,
        {
          limit: isNaN(limitInt) ? 20 : limitInt,
          before: before || undefined,
          after: after || undefined,
        }
      ),
      lastReadCacheClient.get(otherUserId, `private_${userId}`),
    ]);

    if (messagesResult.status === 'rejected') {
      throw messagesResult.reason;
    }
    const { messages, hasMore } = messagesResult.value;

    let theirReadReceipt = null;
    if (lastReadResult.status === 'fulfilled') {
      theirReadReceipt = lastReadResult.value;
    }

    const lastRead = {
      messageId: theirReadReceipt?.messageId ?? null,
      seenAt: theirReadReceipt?.lastSeenAt ?? null,
    };

    if (!messages || !messages.length) {
      const unreadCount = await applyUnreadOnFetch({
        userId,
        chatKey: `private_${otherUserId}`,
        hasMore: false,
        messages: [],
      });
      return res.status(200).json({ messages: [], hasMore: false, lastRead, unreadCount });
    }

    const participantIds = [...new Set([userId, otherUserId])];
    const userDetailsMap = await userCacheClient.getUsersByIds(participantIds);

    const formattedMessages = messages.map((msg) => {
      const isOwn = String(msg.senderId) === String(userId);

      const cachedSender = userDetailsMap.get(msg.senderId);
      const senderDetails = cachedSender && cachedSender.username ? cachedSender : deletedUserFallback(msg);

      return compact({
        _id: msg._id || msg.id,
        senderId: msg.senderId,
        receiverId: msg.receiverId,
        username: senderDetails.username,
        avatar: senderDetails.avatar,
        gender: senderDetails.gender,
        isSystemMessage: msg.isSystemMessage,
        systemType: msg.systemType,
        text: msg.content || msg.text || '',
        iv: msg.iv || null,
        senderKeyWrapped: msg.senderKeyWrapped || null,
        receiverKeyWrapped: msg.receiverKeyWrapped || null,
        isOwn,
        timestamp: msg.timestamp,
        media: msg.media ? _addQualities(msg.media) : null,
        replyTo: msg.replyTo || null,
      });
    });

    const unreadCount = await applyUnreadOnFetch({
      userId,
      chatKey: `private_${otherUserId}`,
      hasMore,
      messages,
    });

    res.status(200).json({ messages: formattedMessages, hasMore, lastRead, unreadCount });
  } catch (error) {
    console.error('Error getting private messages:', error);
    res.status(500).json({ message: 'Failed to get messages', error: error.message });
  }
};