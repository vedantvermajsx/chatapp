import { onlineUsers } from '../socket.js';
import { disconnectTimers } from './disconnect.event.js';
import userCacheClient from '../database/userCacheClient.js';
import roomCacheClient from '../database/roomCacheClient.js';
import { publish } from '../utils/messageBroker.js';
import { flushBufferedSignals } from '../utils/callSessions.js';

export default function handleJoin(socket, io) {
  return async (data) => {
    const { role, username, gender } = data;
    const userId = String(data.userId);
    console.log('User joining:', username);


    const pendingTimer = disconnectTimers.get(userId);
    if (pendingTimer) {
      clearTimeout(pendingTimer);
      disconnectTimers.delete(userId);
    }

    socket.join(String(userId));
    
    try {
      const memberRooms = await roomCacheClient.getRoomsByUserId(userId);
      for (const room of memberRooms) {
        socket.join(String(room._id));
      }
      if (memberRooms.length > 0) {
        console.log(`[socket] ${username} auto-rejoined ${memberRooms.length} room(s)`);
      }
    } catch (err) {
      console.error('[socket] failed to auto-rejoin rooms for', username, err.message);
    }

    onlineUsers.set(userId, {
      socketId: socket.id,
      userId,
      role,
      username,
      gender
    });

    // Callee just (re)connected: replay any offer/ICE buffered while they were away (e.g. app
    // woken by the call push). Uses the authenticated socket user, not the client-sent id.
    const authedId = String(socket.user?._id || socket.user?.id || userId);
    flushBufferedSignals(socket, authedId);

    const lastSeen = new Date();

    await userCacheClient.updateUserById(userId, {
      isOnline: true,
      lastSeen
    });

    publish('user.presence.online', {
      userId,
      lastSeen: lastSeen.toISOString()
    });

    io.emit('userOnline', { userId });
    publish('userOnline', { userId });
  };
}