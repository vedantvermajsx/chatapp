import { on, INSTANCE_ID } from '../utils/messageBroker.js';
import { processSignal } from '../utils/callSessions.js';
import { applyBan } from './ban/applyBan.js';
import { clearBan } from './ban/clearBan.js';

let registered = false;

export function registerBrokerBridge(io, onlineUsers) {
  if (registered) return;
  registered = true;

  on('newRoom', (room) => {
    io.emit('newRoom', room);
  });

  on('newMessage', ({ roomId, payload }) => {
    
    
    
    
    
    
    io.to(roomId).emit('newMessage', payload);
  });

  on('newPrivateMessage', ({ senderId, receiverId, payload }) => {
    io.to(String(receiverId)).emit('newPrivateMessage', payload);
    io.to(String(senderId)).emit('newPrivateMessage', payload);
  });

  on('roomUpdated', (room) => {
    io.emit('roomUpdated', room);
  });

  on('roomDeleted', (data) => {
    io.emit('roomDeleted', data);
  });

  on('userOnline', ({ userId }) => {
    io.emit('userOnline', { userId });
  });

  on('userOffline', ({ userId }) => {
    io.emit('userOffline', { userId });
  });

  on('userJoinedRoom', ({ roomId, data }) => {
    io.to(roomId).emit('userJoinedRoom', data);
  });

  on('userLeftRoom', ({ roomId, data }) => {
    io.to(roomId).emit('userLeftRoom', data);
  });

  on('webrtcSignal', (payload) => {
    const { targetId, origin } = payload;
    if (origin === INSTANCE_ID) return;
    processSignal(payload, { mirror: true });
    if (targetId) {
      io.to(String(targetId)).emit('webrtcSignal', payload);
    }
  });

  on('user.banned', (ban) => applyBan(ban));
  on('user.unbanned', ({ userId }) => clearBan(userId));
}