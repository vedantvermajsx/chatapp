import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  _id: { type: String, required: true },
  username: { type: String, required: true, unique: true },
  gender: { type: Number, required: true },
  bio: { type: String, default: '' },
  avatar: { type: String, default: '' },
  role: { type: String, default: 'user' },
  lastSeen: { type: Date, default: Date.now },
  isOnline: { type: Boolean, default: false },
  publicKey: { type: String, default: null },
  privateKeyEncrypted: { type: String, default: null, select: false },
  keySalt: { type: String, default: null, select: false }
}, { timestamps: true });

export default mongoose.models.User || mongoose.model('User', userSchema);
