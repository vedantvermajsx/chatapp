import express from 'express';
import {
  getUnread,
  incrementUnread,
  incrementUnreadForMembers,
  resetUnread,
  decrementUnread,
  seedUnread,
  invalidateUnread
} from '../controllers/unread/unread.controller.js';

const router = express.Router();

router.get('/:userId', getUnread);
router.post('/members/increment', incrementUnreadForMembers);
router.post('/:userId/increment', incrementUnread);
router.post('/:userId/reset', resetUnread);
router.post('/:userId/decrement', decrementUnread);
router.post('/:userId/seed', seedUnread);
router.delete('/:userId', invalidateUnread);

export default router;
