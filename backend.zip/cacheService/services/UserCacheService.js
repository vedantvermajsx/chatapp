import { userCache } from './CacheService.js';
import User from '../models/user.model.js';
import Guest from '../models/guest.model.js';

const isGuestId = (id) => String(id).startsWith('guest_');

const USER_TTL   = null;
const INDEX_TTL  = null;
const SEARCH_TTL = 30; // seconds

const inFlight = new Map();

async function dedupe(key, fetcher) {
  const existing = inFlight.get(key);
  if (existing) return existing;

  const promise = fetcher().finally(() => inFlight.delete(key));
  inFlight.set(key, promise);
  return promise;
}

function userKey(userId)   { return `user:${userId}`; }
function usernameKey(name) { return `user:username:${name.toLowerCase()}`; }
function emailKey(email)   { return `user:email:${email.toLowerCase()}`; }

function sanitize(user) {
  if (!user) return user;
  const { password, email, ...safe } = user;
  return safe;
}

const UserCacheService = {

  _seed(user) {
    const id = String(user._id);
    const safe = sanitize(user);
    userCache.set(userKey(id), safe, USER_TTL);
    if (user.username) userCache.set(usernameKey(user.username), id, INDEX_TTL);
    if (user.email)    userCache.set(emailKey(user.email),       id, INDEX_TTL);
    return safe;
  },

  seedUser(userDoc) {
    this._seed(userDoc);
    console.log(`[UserCacheService] seeded user ${userDoc._id} into cache`);
  },

  setUser(id, data) {
    const merged = { ...data, _id: id };
    this._seed(merged);
    console.log(`[UserCacheService] set user ${id} in cache`);
  },

  async updateUser(id, patch) {
    const Model = isGuestId(id) ? Guest : User;
    const persisted = await Model.findByIdAndUpdate(
      id,
      { $set: patch },
      { new: true }
    ).lean();

    if (!persisted) {
      const existing = userCache.get(userKey(id)) || {};
      const updated = { ...existing, ...patch, _id: id };
      this._seed(updated);
      console.log(`[UserCacheService] updated user ${id} in cache only (not found in DB)`);
      return updated;
    }

    const updated = this._seed(persisted);
    console.log(`[UserCacheService] updated user ${id} in DB and cache`);
    return updated;
  },

  deleteUser(id) {
    const u = userCache.get(userKey(id));
    if (u) {
      if (u.username) userCache.delete(usernameKey(u.username));
      if (u.email)    userCache.delete(emailKey(u.email));
    }
    userCache.delete(userKey(id));
    console.log(`[UserCacheService] deleted user ${id} from cache`);
  },

  async getUserById(userId) {
    const cached = userCache.get(userKey(userId));
    if (cached) return cached;

    const user = isGuestId(userId)
      ? await Guest.findById(userId).lean()
      : await User.findById(userId).lean();

    if (!user) return null;
    return this._seed(user);
  },

  async getUsersByIds(userIds) {
    const uniqueIds = [...new Set((userIds || []).map(String))];
    const result = new Map();
    const missing = [];

    for (const id of uniqueIds) {
      const cached = userCache.get(userKey(id));
      if (cached) result.set(id, cached);
      else missing.push(id);
    }

    if (missing.length > 0) {
      const guestIds = missing.filter(isGuestId);
      const realUserIds = missing.filter((id) => !isGuestId(id));

      const [users, guests] = await Promise.all([
        realUserIds.length ? User.find({ _id: { $in: realUserIds } }).lean() : [],
        guestIds.length ? Guest.find({ _id: { $in: guestIds } }).lean() : [],
      ]);

      for (const doc of [...users, ...guests]) {
        result.set(String(doc._id), this._seed(doc));
      }
    }

    return result;
  },

  async getUserByUsername(username) {
    const cachedId = userCache.get(usernameKey(username));
    if (cachedId) {
      const u = userCache.get(userKey(cachedId));
      if (u) return u;
    }

    const user = await User.findOne({ username }).lean()
      || await Guest.findOne({ username }).lean();

    if (!user) return null;
    return this._seed(user);
  },

  async getUserByEmail(email) {
    const cachedId = userCache.get(emailKey(email));
    if (cachedId) {
      const u = userCache.get(userKey(cachedId));
      if (u) return u;
    }
    const user = await User.findOne({ email }).lean();
    if (!user) return null;
    return this._seed(user);
  },

  async checkDuplicate(username, email) {
    if (userCache.get(usernameKey(username))) return { taken: true, field: 'username' };
    if (email && userCache.get(emailKey(email))) return { taken: true, field: 'email' };

    const query = email
      ? { $or: [{ email }, { username }] }
      : { username };

    const existing = await User.findOne(query).select('_id email username').lean();
    if (existing) {
      const field = existing.email === email ? 'email' : 'username';
      const idxKey = field === 'email' ? emailKey(email) : usernameKey(username);
      userCache.set(idxKey, String(existing._id), INDEX_TTL);
      return { taken: true, field };
    }

    const existingGuest = await Guest.findOne({ username }).select('_id username').lean();
    if (existingGuest) {
      userCache.set(usernameKey(username), String(existingGuest._id), INDEX_TTL);
      return { taken: true, field: 'username' };
    }

    return { taken: false };
  },

  async searchUsers(query, limit = 5, { excludeId } = {}) {
    const trimmed = (query || '').trim();
    if (!trimmed) return [];

    const cappedLimit = Math.min(Math.max(Number(limit) || 5, 1), 20);
    const cacheKey = `user:search:${trimmed.toLowerCase()}:${cappedLimit}`;
    const cached = userCache.get(cacheKey);
    if (cached) {
      return excludeId ? cached.filter((u) => String(u.userid) !== String(excludeId)) : cached;
    }

    const results = await dedupe(cacheKey, async () => {
      const existing = userCache.get(cacheKey);
      if (existing) return existing;

      const escaped = trimmed.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const regex = new RegExp(`^${escaped}`, 'i');

      const [users, guests] = await Promise.all([
        User.find({ username: regex }).select('_id username avatar publicKey').limit(cappedLimit).lean(),
        Guest.find({ username: regex }).select('_id username avatar publicKey').limit(cappedLimit).lean(),
      ]);

      const mapped = [...users, ...guests]
        .slice(0, cappedLimit)
        .map((u) => ({
          userid: String(u._id),
          username: u.username,
          pfp: u.avatar ?? '',
          publicKey: u.publicKey ?? null,
        }));

      userCache.set(cacheKey, mapped, SEARCH_TTL);
      return mapped;
    });

    return excludeId ? results.filter((u) => String(u.userid) !== String(excludeId)) : results;
  },

  invalidate(userId) {
    const u = userCache.get(userKey(userId));
    if (u) {
      if (u.username) userCache.delete(usernameKey(u.username));
      if (u.email)    userCache.delete(emailKey(u.email));
    }
    userCache.delete(userKey(userId));
  },
};

export default UserCacheService;