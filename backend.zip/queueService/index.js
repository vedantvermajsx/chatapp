import dotenv from 'dotenv';
import BatchQueue from './BatchQueue.js';
import { processMessageBatch } from './processors/message/messageProcessor.js';
import { handleUserRegistered } from './processors/user/userRegistrationProcessor.js';
import { handleUserOffline, handleUserOnline } from './processors/user/userPresenceProcessor.js';
import { handleGuestRegistered } from './processors/guest/guestRegistrationProcessor.js';
import { handleRoomCreated } from './processors/room/handleRoomCreated.js';
import { handleMemberJoined } from './processors/room/handleMemberJoined.js';
import { handleMemberLeft } from './processors/room/handleMemberLeft.js';
import { handleRoomDeleted } from './processors/room/handleRoomDeleted.js';
import { handlePrivateUnread } from './processors/notification/handlePrivateUnread.js';
import { handleRoomLastRead } from './processors/notification/handleRoomLastRead.js';
import { handlePrivateLastRead } from './processors/notification/handlePrivateLastRead.js';
import { handleIpRecorded } from './processors/block/handleIpRecorded.js';
import { handleUserBlocked } from './processors/block/handleUserBlocked.js';
import { handleUserUnblocked } from './processors/block/handleUserUnblocked.js';
import { handleRoomUserBlocked } from './processors/block/handleRoomUserBlocked.js';
import { handleRoomUserUnblocked } from './processors/block/handleRoomUserUnblocked.js';
import { handleUserBanned } from './processors/block/handleUserBanned.js';
import { handleUserUnbanned } from './processors/block/handleUserUnbanned.js';
import { connectToBroker, subscribe, on } from './broker.js';
import { connectDB } from './database/db.js';
import { createAdminServer } from './adminServer.js';
import { startRoomMemberReconciler } from './jobs/reconcileRoomMembers.js';

dotenv.config();

const messageQueue = new BatchQueue({
  name: 'messageQueue',
  batchSize: 50,
  flushInterval: 500,
  maxSize: 30000,
  processBatch: processMessageBatch,
});

const userQueue = new BatchQueue({
  name: 'userQueue',
  batchSize: 1,
  flushInterval: 100,
  maxSize: 10000,
  processBatch: ([item]) => handleUserRegistered(item),
});

const guestQueue = new BatchQueue({
  name: 'guestQueue',
  batchSize: 1,
  flushInterval: 100,
  maxSize: 10000,
  processBatch: ([item]) => handleGuestRegistered(item),
});

const presenceQueue = new BatchQueue({
  name: 'presenceQueue',
  batchSize: 1,
  flushInterval: 100,
  maxSize: 10000,
  processBatch: ([item]) => {
    const { _eventType, ...payload } = item;
    if (_eventType === 'user.presence.online') return handleUserOnline(payload);
    if (_eventType === 'user.presence.offline') return handleUserOffline(payload);
  },
});

const roomQueue = new BatchQueue({
  name: 'roomQueue',
  batchSize: 1,
  flushInterval: 100,
  maxSize: 10000,
  processBatch: async ([item]) => {
    const { _eventType, ...payload } = item;
    if (_eventType === 'room.created') return handleRoomCreated(payload);
    if (_eventType === 'room.member.joined') return handleMemberJoined(payload);
    if (_eventType === 'room.member.left') return handleMemberLeft(payload);
    if (_eventType === 'room.deleted') return handleRoomDeleted(payload);
  },
});

const notificationQueue = new BatchQueue({
  name: 'notificationQueue',
  batchSize: 1,
  flushInterval: 100,
  maxSize: 10000,
  processBatch: async ([item]) => {
    const { _eventType, ...payload } = item;
    if (_eventType === 'notification.unread.private') return handlePrivateUnread(payload);
    if (_eventType === 'notification.lastread.room') return handleRoomLastRead(payload);
    if (_eventType === 'notification.lastread.private') return handlePrivateLastRead(payload);
  },
});

const blockQueue = new BatchQueue({
  name: 'blockQueue',
  batchSize: 1,
  flushInterval: 100,
  maxSize: 10000,
  processBatch: async ([item]) => {
    const { _eventType, ...payload } = item;
    if (_eventType === 'user.ip.recorded') return handleIpRecorded(payload);
    if (_eventType === 'user.blocked') return handleUserBlocked(payload);
    if (_eventType === 'user.unblocked') return handleUserUnblocked(payload);
    if (_eventType === 'room.user.blocked') return handleRoomUserBlocked(payload);
    if (_eventType === 'room.user.unblocked') return handleRoomUserUnblocked(payload);
    if (_eventType === 'user.banned') return handleUserBanned(payload);
    if (_eventType === 'user.unbanned') return handleUserUnbanned(payload);
  },
});

async function start() {
  await connectDB();
  connectToBroker();

  subscribe('message.created');
  on('message.created', (data) => messageQueue.add(data));

  subscribe('user.registered');
  on('user.registered', (data) => userQueue.add(data));
 // console.log('[UserRegistrationProcessor] subscribed to user.registered');

  subscribe('guest.registered');
  on('guest.registered', (data) => guestQueue.add(data));
  //console.log('[GuestRegistrationProcessor] subscribed to guest.registered');

  subscribe('user.presence.online');
  on('user.presence.online', (data) => presenceQueue.add({ _eventType: 'user.presence.online', ...data }));

  subscribe('user.presence.offline');
  on('user.presence.offline', (data) => presenceQueue.add({ _eventType: 'user.presence.offline', ...data }));
  //console.log('[UserPresenceProcessor] subscribed to user.presence.online, user.presence.offline');

  subscribe('room.created');
  on('room.created', (data) => roomQueue.add({ _eventType: 'room.created', ...data }));

  subscribe('room.member.joined');
  on('room.member.joined', (data) => roomQueue.add({ _eventType: 'room.member.joined', ...data }));

  subscribe('room.member.left');
  on('room.member.left', (data) => roomQueue.add({ _eventType: 'room.member.left', ...data }));

  subscribe('room.deleted');
  on('room.deleted', (data) => roomQueue.add({ _eventType: 'room.deleted', ...data }));

  //console.log('[RoomProcessor] subscribed to room.created, room.member.joined, room.member.left, room.deleted');

  subscribe('notification.unread.private');
  on('notification.unread.private', (data) => notificationQueue.add({ _eventType: 'notification.unread.private', ...data }));

  subscribe('notification.lastread.room');
  on('notification.lastread.room', (data) => notificationQueue.add({ _eventType: 'notification.lastread.room', ...data }));

  subscribe('notification.lastread.private');
  on('notification.lastread.private', (data) => notificationQueue.add({ _eventType: 'notification.lastread.private', ...data }));

  //console.log('[NotificationProcessor] subscribed to notification.* channels');

  for (const channel of ['user.ip.recorded', 'user.blocked', 'user.unblocked', 'room.user.blocked', 'room.user.unblocked', 'user.banned', 'user.unbanned']) {
    subscribe(channel);
    on(channel, (data) => blockQueue.add({ _eventType: channel, ...data }));
  }

  startRoomMemberReconciler();

  createAdminServer({
    port: process.env.PORT || 6000,
    getStats: () => ({
      messageQueue: messageQueue.getStats(),
      userQueue: userQueue.getStats(),
      guestQueue: guestQueue.getStats(),
      presenceQueue: presenceQueue.getStats(),
      roomQueue: roomQueue.getStats(),
      notificationQueue: notificationQueue.getStats(),
      blockQueue: blockQueue.getStats(),
    }),
  });

}

start().catch((err) => {
  console.error('[QueueService] failed to start:', err);
  process.exit(1);
});

async function shutdown(signal) {
  console.log(`[QueueService] ${signal} received, draining queues`);
  const queues = [messageQueue, userQueue, guestQueue, presenceQueue, roomQueue, notificationQueue, blockQueue];
  await Promise.allSettled(queues.map((q) => q.drain(10000)));
  console.log('[QueueService] shutting down');
  process.exit(0);
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('unhandledRejection', (err) => console.error('[QueueService] unhandledRejection:', err));
