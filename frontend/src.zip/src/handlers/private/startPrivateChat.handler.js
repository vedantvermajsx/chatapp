import messageService from '../../services/message.service.js';
import { dbService } from '../../services/indexedDB.service.js';
import { applyLastRead } from '../../utils/applyLastRead.js';
import { syncUnreadFromResponse } from '../../utils/syncUnreadCount.js';

export const startPrivateChatHandler = async (
  otherUser,
  user,
  setCurrentPrivateChat,
  setCurrentRoom,
  setShowMembersModal,
  setMessages,
  setLoadingMessages,
  setHasMoreMessages,
  setHasMoreNewerMessages,
  messageCache,
  CACHE_TTL,
  unreadCount = 0,
  setUnreadCounts = null
) => {
  setCurrentPrivateChat(otherUser);
  setCurrentRoom(null);
  setShowMembersModal(false);

  const cacheKey = `private_${otherUser.id}`;

  const inMemory = messageCache.current[cacheKey];
  if (inMemory?.messages?.length && Date.now() - inMemory.timestamp < CACHE_TTL) {
    setMessages(inMemory.messages);
    setHasMoreMessages(inMemory.hasMore);
    setLoadingMessages(false);
    if (unreadCount > 0) {
      _fetchNewPrivateMessages(otherUser.id, cacheKey, inMemory, setMessages, setHasMoreMessages, setHasMoreNewerMessages, messageCache, unreadCount, setUnreadCounts);
    }
    return;
  }

  const idbData = await dbService.getMessages(cacheKey);
  if (idbData.messages.length > 0) {
    setMessages(idbData.messages);
    setHasMoreMessages(idbData.hasMore);
    setLoadingMessages(false);
    messageCache.current[cacheKey] = {
      messages: idbData.messages,
      hasMore: idbData.hasMore,
      timestamp: Date.now(),
    };
    if (unreadCount > 0) {
      _fetchNewPrivateMessages(otherUser.id, cacheKey, messageCache.current[cacheKey], setMessages, setHasMoreMessages, setHasMoreNewerMessages, messageCache, unreadCount, setUnreadCounts);
    }
    return;
  }

  setMessages([]);
  setLoadingMessages(true);
  try {
    const res = await messageService.getPrivateMessages(otherUser.id, 20);
    const messagesWithRead = applyLastRead(res.messages, res.lastRead);
    messageCache.current[cacheKey] = {
      messages: messagesWithRead,
      hasMore: res.hasMore,
      timestamp: Date.now(),
    };
    setMessages(messagesWithRead);
    setHasMoreMessages(res.hasMore);
    await dbService.saveMessages(cacheKey, messagesWithRead, res.hasMore);
    syncUnreadFromResponse(setUnreadCounts, cacheKey, res.unreadCount);
  } catch (error) {
    const idbFallback = await dbService.getMessages(cacheKey);
    if (idbFallback.messages.length > 0) {
      setMessages(idbFallback.messages);
      setHasMoreMessages(idbFallback.hasMore);
    }
    console.error('Failed to load private messages:', error);
  } finally {
    setLoadingMessages(false);
  }
};

async function _fetchNewPrivateMessages(otherUserId, cacheKey, currentCache, setMessages, setHasMoreMessages, setHasMoreNewerMessages, messageCache, unreadCount, setUnreadCounts) {
  try {
    let latestTimestamp = currentCache.messages?.[currentCache.messages.length - 1]?.timestamp;
    if (!latestTimestamp) return;

    let mergedMessages = currentCache.messages;
    let lastRead = null;
    const fetchLimit = unreadCount > 0 ? Math.min(unreadCount, 20) : 20;

    const res = await messageService.getPrivateMessages(otherUserId, fetchLimit, null, latestTimestamp);
    lastRead = res.lastRead ?? lastRead;

    const existingIds = new Set(mergedMessages.map(m => String(m.id)));
    const reallyNew = (res.messages || []).filter(m => !existingIds.has(String(m.id)));

    if (reallyNew.length) {
      mergedMessages = [...mergedMessages, ...reallyNew];
      await dbService.mergeNewMessages(cacheKey, reallyNew);
    }

    if (lastRead) {
      mergedMessages = applyLastRead(mergedMessages, lastRead);
    }

    messageCache.current[cacheKey] = {
      messages: mergedMessages,
      hasMore: currentCache.hasMore,
      timestamp: Date.now(),
    };
    setMessages(mergedMessages);
    if (setHasMoreNewerMessages) setHasMoreNewerMessages(res.hasMore || false);
    syncUnreadFromResponse(setUnreadCounts, cacheKey, res.unreadCount);
  } catch {
  }
}
