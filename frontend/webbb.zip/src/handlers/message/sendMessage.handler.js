import { registerUpload, releaseUpload, isUploadCancelled } from '../../services/uploadCancel.js';
import messageService from '../../services/message.service.js';
import { updatePrivateChatOptimistically } from '../private/updatePrivateChatOptimistically.handler.js';
import { dbService } from '../../services/indexedDB.service.js';
import { capNewest, withCap } from '../../utils/messageList.js';
import { toast } from 'sonner';
import { maskProfanity, addProfanityCount, isProfanityBlocked, getProfanityCount, PROFANITY_LIMIT, PROFANITY_BLOCK_MESSAGE } from '../../utils/profanity.js';

function replaceAndDedupe(prev, tempId, finalMessage) {
  const finalId = finalMessage.id ?? finalMessage._id;
  const replaced = prev.map((msg) => {
    const msgId = msg.id ?? msg._id;
    return msgId === tempId || msgId === finalId ? finalMessage : msg;
  });
  const seen = new Set();
  return replaced.filter((msg) => {
    const key = msg.id ?? msg._id;
    if (key == null) return true;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

export const sendMessageHandler = async (
  e,
  currentRoom,
  currentPrivateChat,
  user,
  inputMessage,
  setInputMessage,
  socket,
  setMessages,
  privateChats,
  setPrivateChats,
  messageCache,
  selectedFile,
  setSelectedFile,
  taggedUserId,
  setTaggedUserId,
  replyingTo,
  setReplyingTo
) => {
  e.preventDefault();
  const rawMessage = (inputMessage || '').trim();
  if (!rawMessage && !selectedFile) return;

  const profanityUserId = user?._id || user?.id;
  if (isProfanityBlocked(profanityUserId)) {
    toast.error(PROFANITY_BLOCK_MESSAGE);
    return;
  }
  const { text: trimmedMessage, count: badWordCount } = maskProfanity(rawMessage);
  if (badWordCount > 0) {
    const total = addProfanityCount(profanityUserId, badWordCount);
    if (total > PROFANITY_LIMIT) {
      toast.error(PROFANITY_BLOCK_MESSAGE);
      return;
    }
    toast.warning(`Please keep it clean. Warning ${total}/${PROFANITY_LIMIT} - you will be blocked from messaging and calls after that.`);
  }

  const replySnapshot = replyingTo
    ? { messageId: replyingTo.id || replyingTo._id, text: replyingTo.text, username: replyingTo.username, media: replyingTo.media, senderId: replyingTo.senderId }
    : null;
  setReplyingTo?.(null);

  const tempId = crypto.randomUUID();
  let pendingMedia = null;
  let localPreviewUrl = null;

  if (selectedFile) {
    localPreviewUrl = URL.createObjectURL(selectedFile);
    pendingMedia = {
      type: selectedFile.type.startsWith('image/gif') ? 'gif' : selectedFile.type.startsWith('video') ? 'video' : 'image',
      url: localPreviewUrl,
      isPending: true
    };
  }



  const optimisticMessage = {
  id: tempId,
  username: user.username,
  senderId: user._id || user.id,
  text: trimmedMessage,
  isOwn: true,
  timestamp: new Date().toISOString(),
  gender: user.gender,
  avatar: user.avatar || null,
  media: pendingMedia,
  uploadProgress: 0,
  isPending: true,
  taggedUser: replySnapshot?.senderId || (currentRoom ? (taggedUserId || null) : null),
  replyTo: replySnapshot
};

  if (currentRoom) {
    setMessages((prev) => capNewest([...prev, optimisticMessage]));
    const cacheKey = `room_${currentRoom._id}`;
    if (messageCache.current[cacheKey]) {
      messageCache.current[cacheKey] = withCap(messageCache.current[cacheKey], [...messageCache.current[cacheKey].messages, optimisticMessage]);
    }
    await dbService.addMessage(cacheKey, optimisticMessage);
  } else if (currentPrivateChat) {
    setMessages((prev) => capNewest([...prev, optimisticMessage]));
    const cacheKey = `private_${currentPrivateChat.id}`;
    if (messageCache.current[cacheKey]) {
      messageCache.current[cacheKey] = withCap(messageCache.current[cacheKey], [...messageCache.current[cacheKey].messages, optimisticMessage]);
    }
    await dbService.addMessage(cacheKey, optimisticMessage);
  }

  setInputMessage('');
  setSelectedFile(null);
  const messageTaggedUserId = replySnapshot?.senderId || (currentRoom ? (taggedUserId || null) : null);
  setTaggedUserId?.(null);

  (async () => {
    try {
      let finalMedia = pendingMedia;

      const pendingMessageData = {
        id: tempId,
        text: trimmedMessage,
        media: pendingMedia,
        mediaType: pendingMedia?.type || null,
        mediaId: selectedFile ? tempId : null,
        timestamp: new Date().toISOString(),
        username: user.username,
        avatar: user.avatar || null,
        gender: user.gender
      };

      if (currentRoom) {
        pendingMessageData.type = 'room';
        pendingMessageData.roomId = currentRoom._id;
        pendingMessageData.roomPublicKey = currentRoom.publicKey || null;
      } else if (currentPrivateChat) {
        pendingMessageData.type = 'private';
        pendingMessageData.receiverId = currentPrivateChat.id.toString();
        pendingMessageData.receiverModel = currentPrivateChat.role === 'guest' ? 'Guest' : 'User';
      }

      await dbService.addPendingMessage(pendingMessageData);
      if (selectedFile) {
        await dbService.addFile(tempId, selectedFile);
      }

      if (!navigator.onLine) {
        return;
      }

      let finalMediaToUse = finalMedia;
      if (selectedFile) {
        const uploadController = registerUpload(tempId);
        let uploadResult;
        try {
        uploadResult = await messageService.uploadFile(
  selectedFile,
  'data',
  false,
  (progress) => {
    setMessages(prev =>
      prev.map(msg =>
        (msg.id || msg._id) === tempId
          ? {
              ...msg,
              uploadProgress: progress
            }
          : msg
      )
    );

    const cacheKey = currentRoom
      ? `room_${currentRoom._id}`
      : `private_${currentPrivateChat.id}`;

    if (messageCache.current[cacheKey]) {
      messageCache.current[cacheKey] = {
        ...messageCache.current[cacheKey],
        messages: messageCache.current[cacheKey].messages.map(msg =>
          (msg.id || msg._id) === tempId
            ? {
                ...msg,
                uploadProgress: progress
              }
            : msg
        )
      };
    }
  },
  uploadController.signal
);
        } finally {
          releaseUpload(tempId);
        }

        finalMediaToUse = {
          ...uploadResult,
          isPending: false
        };
        
        setMessages(prev =>
          prev.map(msg =>
            (msg.id || msg._id) === tempId
              ? {
                  ...msg,
                  uploadProgress: null
                }
              : msg
          )
        );
        
        const cacheKeyAfterUpload = currentRoom
          ? `room_${currentRoom._id}`
          : `private_${currentPrivateChat.id}`;

        if (messageCache.current[cacheKeyAfterUpload]) {
          messageCache.current[cacheKeyAfterUpload] = {
            ...messageCache.current[cacheKeyAfterUpload],
            messages: messageCache.current[cacheKeyAfterUpload].messages.map(msg =>
              (msg.id || msg._id) === tempId
                ? {
                    ...msg,
                    uploadProgress: null
                  }
                : msg
            )
          };
        }
        
        if (localPreviewUrl) URL.revokeObjectURL(localPreviewUrl);
        await dbService.addPendingMessage({ ...pendingMessageData, media: finalMediaToUse });
      }

      if (currentRoom) {
        const response = await messageService.sendRoomMessage({
          roomId: currentRoom._id,
          text: trimmedMessage,
          media: finalMediaToUse,
          uuid: tempId,
          roomPublicKey: currentRoom.publicKey,
          taggedUser: messageTaggedUserId,
          replyTo: replySnapshot?.messageId
        });

        const newMessageObj = {
          id: response._id,
          username: user.username,
          senderId: user._id || user.id,
          text: trimmedMessage,
          isOwn: true,
          timestamp: response.timestamp,
          gender: user.gender,
          avatar: user.avatar || null,
          media: finalMediaToUse,
          isPending: false,
          taggedUser: messageTaggedUserId,
          replyTo: replySnapshot
        };

        setMessages((prev) => replaceAndDedupe(prev, tempId, newMessageObj));

        const cacheKey = `room_${currentRoom._id}`;
        if (messageCache.current[cacheKey]) {
          messageCache.current[cacheKey] = {
            ...messageCache.current[cacheKey],
            messages: messageCache.current[cacheKey].messages.map((msg) =>
              (msg.id || msg._id) === tempId || (msg.id || msg._id) === newMessageObj.id ? newMessageObj : msg
            )
          };
        }
        await dbService.addMessage(cacheKey, newMessageObj);
        if (tempId !== newMessageObj.id) await dbService.removeMessage(cacheKey, tempId);
        await dbService.removePendingMessage(tempId);
        if (selectedFile) await dbService.removeFile(tempId);
      } else if (currentPrivateChat) {
        const response = await messageService.sendPrivateMessage({
          receiverId: currentPrivateChat.id.toString(),
          receiverModel: currentPrivateChat.role === 'guest' ? 'Guest' : 'User',
          content: trimmedMessage,
          media: finalMediaToUse,
          uuid: tempId,
          replyTo: replySnapshot?.messageId,
          taggedUser: messageTaggedUserId
        });

        const newMessageObj = {
          id: response._id,
          username: user.username,
          senderId: user._id || user.id,
          text: trimmedMessage,
          isOwn: true,
          timestamp: response.timestamp,
          gender: user.gender,
          avatar: user.avatar || null,
          media: finalMediaToUse,
          isPending: false,
          taggedUser: messageTaggedUserId,
          replyTo: replySnapshot
        };
        
        setMessages((prev) => replaceAndDedupe(prev, tempId, newMessageObj));

        const cacheKey = `private_${currentPrivateChat.id}`;
        if (messageCache.current[cacheKey]) {
          messageCache.current[cacheKey] = {
            ...messageCache.current[cacheKey],
            messages: messageCache.current[cacheKey].messages.map((msg) =>
              (msg.id || msg._id) === tempId || (msg.id || msg._id) === newMessageObj.id ? newMessageObj : msg
            )
          };
        }
        await dbService.addMessage(cacheKey, newMessageObj);
        if (tempId !== newMessageObj.id) await dbService.removeMessage(cacheKey, tempId);
        await dbService.removePendingMessage(tempId);
        if (selectedFile) await dbService.removeFile(tempId);

        updatePrivateChatOptimistically(privateChats, setPrivateChats, currentPrivateChat, trimmedMessage);
      }
    } catch (error) {
      if (isUploadCancelled(tempId)) return;
      if (error?.response?.status === 403) {
        const blockedKey = currentRoom ? `room_${currentRoom._id}` : `private_${currentPrivateChat?.id}`;
        setMessages((prev) => prev.filter((m) => (m.id || m._id) !== tempId));
        if (messageCache.current[blockedKey]) {
          messageCache.current[blockedKey] = {
            ...messageCache.current[blockedKey],
            messages: messageCache.current[blockedKey].messages.filter((m) => (m.id || m._id) !== tempId)
          };
        }
        await dbService.removeMessage(blockedKey, tempId);
        await dbService.removePendingMessage(tempId);
        if (selectedFile) await dbService.removeFile(tempId);
        return;
      }
      console.error('Failed to send message immediately:', error);
    }
  })();
};


export const sendStickerHandler = async (
  sticker,
  currentRoom,
  currentPrivateChat,
  user,
  setMessages,
  privateChats,
  setPrivateChats,
  messageCache
) => {
  if (!sticker?.url) return;

  const tempId = crypto.randomUUID();

  const stickerMedia = {
    type: 'sticker',
    url: sticker.url,
    isPending: true
  };

  const optimisticMessage = {
    id: tempId,
    username: user.username,
    text: '',
    isOwn: true,
    timestamp: new Date().toISOString(),
    gender: user.gender,
    avatar: user.avatar || null,
    media: stickerMedia,
    isPending: true
  };

  if (currentRoom) {
    setMessages((prev) => capNewest([...prev, optimisticMessage]));
    const cacheKey = `room_${currentRoom._id}`;
    if (messageCache.current[cacheKey]) {
      messageCache.current[cacheKey] = withCap(messageCache.current[cacheKey], [...messageCache.current[cacheKey].messages, optimisticMessage]);
    }
    await dbService.addMessage(cacheKey, optimisticMessage);
  } else if (currentPrivateChat) {
    setMessages((prev) => capNewest([...prev, optimisticMessage]));
    const cacheKey = `private_${currentPrivateChat.id}`;
    if (messageCache.current[cacheKey]) {
      messageCache.current[cacheKey] = withCap(messageCache.current[cacheKey], [...messageCache.current[cacheKey].messages, optimisticMessage]);
    }
    await dbService.addMessage(cacheKey, optimisticMessage);
  }

  (async () => {
    try {
      const finalMedia = { type: 'sticker', url: sticker.url, isPending: false };

      let response;
      if (currentRoom) {
        response = await messageService.sendRoomMessage({
          roomId: currentRoom._id,
          text: '',
          media: finalMedia,
          uuid: tempId,
          roomPublicKey: currentRoom.publicKey
        });
      } else if (currentPrivateChat) {
        response = await messageService.sendPrivateMessage({
          receiverId: currentPrivateChat.id.toString(),
          receiverModel: currentPrivateChat.role === 'guest' ? 'Guest' : 'User',
          content: '',
          media: finalMedia,
          uuid: tempId
        });
      }

      if (!response) return;

      const newMessageObj = {
        id: response._id,
        username: user.username,
        text: '',
        isOwn: true,
        timestamp: response.timestamp,
        gender: user.gender,
        avatar: user.avatar || null,
        media: finalMedia,
        isPending: false
      };

      setMessages((prev) => replaceAndDedupe(prev, tempId, newMessageObj));

      if (currentRoom) {
        const cacheKey = `room_${currentRoom._id}`;
        if (messageCache.current[cacheKey]) {
          messageCache.current[cacheKey] = {
            ...messageCache.current[cacheKey],
            messages: messageCache.current[cacheKey].messages.map((msg) =>
              (msg.id || msg._id)  === tempId || (msg.id || msg._id) === newMessageObj.id ? newMessageObj : msg
            )
          };
        }
        await dbService.addMessage(cacheKey, newMessageObj);
        if (tempId !== newMessageObj.id) await dbService.removeMessage(cacheKey, tempId);
      } else if (currentPrivateChat) {
        const cacheKey = `private_${currentPrivateChat.id}`;
        if (messageCache.current[cacheKey]) {
          messageCache.current[cacheKey] = {
            ...messageCache.current[cacheKey],
            messages: messageCache.current[cacheKey].messages.map((msg) =>
              (msg.id || msg._id)  === tempId || (msg.id || msg._id) === newMessageObj.id ? newMessageObj : msg
            )
          };
        }
        await dbService.addMessage(cacheKey, newMessageObj);
        if (tempId !== newMessageObj.id) await dbService.removeMessage(cacheKey, tempId);
        updatePrivateChatOptimistically(privateChats, setPrivateChats, currentPrivateChat, '🎭');
      }
    } catch (error) {
      console.error('Failed to send sticker:', error);
    }
  })();
};